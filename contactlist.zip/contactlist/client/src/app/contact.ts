export class Contact{
    _id?: string;
    Name: string;
    Phone: string;
    Email: string;
}