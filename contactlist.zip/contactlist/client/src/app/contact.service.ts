import { Injectable } from '@angular/core';
import {HttpClient, HttpHeaders } from '@angular/common/http';
import {map} from 'rxjs/operators';
import { Contact } from './contact';

@Injectable()
export class ContactService {
  
  constructor(private http: HttpClient) { }
  getContacts()
  {
    return this.http.get('http://localhost:3000/api/contacts')
      // .pipe(map(res => res.json() as Contact[]));
      .pipe(map((res: any) => res.json()));
  }
  addContact(newContact: any)
  {
    var headers = new Headers();
    headers.append('Content-Type', 'application/json');
    return this.http.post('http://localhost:3000/api/contact', newContact,{headers: new HttpHeaders})
      // .pipe(map(res => res.json() as  Contact));
      // .pipe(map(res => res ));
      .pipe(map((res: any) => res.json()));
  }
  deleteContact(id: string)
  {
    return this.http.delete('http://localhost:3000/api/contact'+id)
      // .pipe(map(res => res.() as String));
      // .pipe(map(res => res ));
      .pipe(map((res: any) => res.json()));
  }
}
