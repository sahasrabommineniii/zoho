import { Component, OnInit } from '@angular/core';
import { ContactService } from '../contact.service';
import { Contact } from '../contact';

@Component({
  selector: 'app-contacts',
  templateUrl: './contacts.component.html',
  styleUrls: ['./contacts.component.css'],
  providers: [ContactService]
})
export class ContactsComponent implements OnInit {
  contacts: Contact[];
  contact: Contact;
  Name: string;
  Phone: string;
  Email: string;

  constructor(private contactService: ContactService) { }

  addContact()
  {
    const newContact ={
      Name: this.Name,
      Phone: this.Phone,
      Email: this.Email
    }
    this.contactService.addContact(newContact)
      .subscribe( contact => {
        this.contacts.push(contact)});
  }

  ngOnInit() {
    this.contactService.getContacts()
      .subscribe( contacts => 
        this.contacts = contacts);
  }


}
