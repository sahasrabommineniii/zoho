import React, { Component }  from 'react';
// import home from "./components/home";
// import userhome from "./components/userhome";
import login from "./components/login"
import {BrowserRouter as Router,Switch,Route} from "react-router-dom";
function App() {
    return (
    <div className="App">
        <Router>
            <Switch>
                <Route exact path="/login" component= {login} />
                {/* <Route exact path="/userhome" component= {userhome} />
                <Route exact path="/home" component= {home} /> */}
            </Switch>
        </Router>
    </div>
    );
}
export default App;
export * from "react-router";

